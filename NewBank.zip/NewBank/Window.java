package NewBank;

public class Window {
    public void call() {}
    public void startWork() {}
    public void breakForDinner() {}
}
