package NewBank;

public class BankSystem {
    private int status;
    public int compareWithDataBase () {
        return 1;
    }
    public int comparePersonalInformation () {return 1;}
    public int getIdentity () {return 1;}
    public void sendAnswerToTerminal() {}
}
