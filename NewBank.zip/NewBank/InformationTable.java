package NewBank;

public class InformationTable {
    private String [] allUSers;
    public void printAllUsers (String [] users) {}
    public void getTime () {}
}
